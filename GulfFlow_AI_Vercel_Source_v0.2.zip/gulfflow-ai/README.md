# GulfFlow AI — Vercel-ready source (v0.2)

A polished Next.js / React / TypeScript prototype for the GulfFlow AI automation agency, including a fully interactive browser demo and an optional Supabase-backed authenticated pilot.

## What works immediately (no environment variables)

- `/` — responsive marketing website
- `/demo` — responsive multi-section dashboard with overview metrics, lead pipeline, searchable lead table, CSV export, add lead, status progression, booking creation/confirmation, FAQ simulation, and demo configuration
- Demo leads and bookings persist to the **current browser's localStorage**. They are not synced to a server. All example customers and metrics are fictional.
- The AI receptionist in `/demo` is a **deterministic FAQ simulation**, not a live AI model.
- Automations in `/demo` are **planned UI previews**, not running workflows.

## Optional connected pilot (requires Supabase)

- `/login` — Supabase email/password login and signup
- `/dashboard` — authenticated lead and booking CRUD, scoped by membership
- `/api/assistant` — authenticated approved-knowledge assistant endpoint (see implementation for AI provider configuration)
- `supabase/schema.sql` — tenant-isolated tables and RLS policies

**Important:** The connected pilot is deliberately more basic than the demo dashboard. Demo UI interactions are not automatically connected to Supabase. The project is not a production SaaS yet. New accounts require administrator assignment to a business; see schema comments. Do not deploy to paying customers until the production security and compliance checklist is completed.

## Deploy to Vercel

Vercel deploys from a Git repository, not directly from a ZIP in the standard Git import workflow.

1. Extract the ZIP.
2. Create a **private GitHub repository**, then upload/push the extracted files (not the enclosing ZIP).
3. In Vercel, select **Add New → Project → Import Git Repository**.
4. Framework: **Next.js**; root directory: project root; build command: `npm run build`.
5. Deploy without environment variables to use `/` and `/demo`. The authenticated routes require Supabase environment variables.
6. For Supabase integration, create a Supabase project and run `supabase/schema.sql` in SQL Editor. Configure:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `OPENAI_API_KEY` (only if enabling the API assistant)
7. Redeploy after configuring environment variables. Set your Supabase authentication redirect/site URLs to your actual deployment domain.

## Run locally

Requires Node.js 20+.

```bash
npm install
npm run dev
```

Visit http://localhost:3000 and http://localhost:3000/demo.

```bash
npm run build
npm run typecheck
```

## Security and production requirements

- Verify row-level security with **two separate authenticated businesses**; attempt cross-tenant reads/writes.
- Implement audited business onboarding, membership invitations, and role management.
- Add secure rate limiting, anti-abuse controls, input validation, structured logging, error monitoring and backups.
- Replace localStorage demo with secure authenticated Supabase-backed pages and server-side tenant authorization.
- Implement production-grade AI prompt-injection defenses, knowledge approval, human handoff and cost caps.
- Implement consent, retention, privacy notices and appropriate Qatar/GCC legal checks before collecting real customer data.
- Configure approved WhatsApp Business integrations and licensed n8n workflows only after commercial/legal review.
- Confirm commercial activity permissions for the founder's Qatar employment/residency status.

## Project structure

- `app/page.tsx` — marketing site
- `app/demo/page.tsx` — interactive UI
- `app/demo/style.css` — dashboard design system
- `app/login/page.tsx` — Supabase auth
- `app/dashboard/*` — connected pilot
- `app/api/assistant/route.ts` — connected assistant
- `supabase/schema.sql` — database/RLS

## Verification status

The source package is created and checked for required files. A complete Next.js build was **not** run in the authoring environment because dependency installation timed out. Run `npm install && npm run build` in your own environment or Vercel and address any compiler or dependency issues before considering it deploy-verified.
