-- Run in Supabase SQL Editor. RLS is mandatory for every tenant table.
create extension if not exists pgcrypto;
create table public.businesses(id uuid primary key default gen_random_uuid(),name text not null,created_at timestamptz not null default now());
create table public.business_memberships(business_id uuid not null references public.businesses(id) on delete cascade,user_id uuid not null references auth.users(id) on delete cascade,role text not null check(role in ('owner','staff')),primary key(business_id,user_id));
create table public.leads(id uuid primary key default gen_random_uuid(),business_id uuid not null references public.businesses(id) on delete cascade,name text not null,email text,phone text,status text not null default 'new' check(status in ('new','contacted','qualified','closed')),created_at timestamptz not null default now());
create table public.booking_requests(id uuid primary key default gen_random_uuid(),business_id uuid not null references public.businesses(id) on delete cascade,customer_name text not null,service_name text not null,requested_at timestamptz not null,status text not null default 'pending' check(status in ('pending','confirmed','rejected')),created_at timestamptz not null default now());
create table public.knowledge_entries(id uuid primary key default gen_random_uuid(),business_id uuid not null references public.businesses(id) on delete cascade,question text not null,answer text not null,approved boolean not null default false,created_at timestamptz not null default now());
create index on public.business_memberships(user_id);
create index on public.leads(business_id,created_at desc);
create index on public.booking_requests(business_id,created_at desc);
create index on public.knowledge_entries(business_id,approved);
create or replace function public.is_business_member(target uuid) returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.business_memberships m where m.business_id=target and m.user_id=(select auth.uid()))$$;
create or replace function public.is_business_owner(target uuid) returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.business_memberships m where m.business_id=target and m.user_id=(select auth.uid()) and m.role='owner')$$;
revoke all on function public.is_business_member(uuid) from public;
revoke all on function public.is_business_owner(uuid) from public;
grant execute on function public.is_business_member(uuid) to authenticated;
grant execute on function public.is_business_owner(uuid) to authenticated;
alter table public.businesses enable row level security;
alter table public.business_memberships enable row level security;
alter table public.leads enable row level security;
alter table public.booking_requests enable row level security;
alter table public.knowledge_entries enable row level security;
create policy business_read on public.businesses for select to authenticated using(public.is_business_member(id));
create policy membership_read on public.business_memberships for select to authenticated using(public.is_business_member(business_id));
create policy leads_read on public.leads for select to authenticated using(public.is_business_member(business_id));
create policy leads_insert on public.leads for insert to authenticated with check(public.is_business_member(business_id));
create policy leads_update on public.leads for update to authenticated using(public.is_business_member(business_id)) with check(public.is_business_member(business_id));
create policy bookings_read on public.booking_requests for select to authenticated using(public.is_business_member(business_id));
create policy bookings_insert on public.booking_requests for insert to authenticated with check(public.is_business_member(business_id));
create policy bookings_update on public.booking_requests for update to authenticated using(public.is_business_member(business_id)) with check(public.is_business_member(business_id));
create policy knowledge_read on public.knowledge_entries for select to authenticated using(public.is_business_member(business_id));
create policy knowledge_insert on public.knowledge_entries for insert to authenticated with check(public.is_business_owner(business_id));
create policy knowledge_update on public.knowledge_entries for update to authenticated using(public.is_business_owner(business_id)) with check(public.is_business_owner(business_id));
-- Onboarding intentionally requires an administrator: create a business and assign an owner
-- in Supabase SQL Editor using verified auth.users.id. Never expose service-role keys to the browser.
